from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import update_session_auth_hash
from .forms import UserEditForm, ProfileEditForm

from .forms import UserRegistrationForm  
from .models import Rol, User, Profile, Categoria, Tutoria
from .forms import LoginForm, TutoriaForm, AdminUserEditForm, AdminTutoriaForm, AdminCategoriaForm, RolForm

#Verificar si el usuario es tutor
def tutor_required(view_func):
    def _wrapped_view(request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.error(request, "Debes iniciar sesión para acceder a esta sección.")
            return redirect('login')

        # Verificar si el usuario tiene el rol con id == 2 (rol tutor)
        if not request.user.rol or request.user.rol.id != 2:
            messages.error(request, "No tienes permisos para realizar esta acción.")
            return redirect('inicio')

        return view_func(request, *args, **kwargs)
    return _wrapped_view

#Verificar si el usuario es admin
def admin_required(view_func):
    def _wrapped_view(request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.error(request, "Debes iniciar sesión para acceder a esta sección.")
            return redirect('login')

        # Verificar si el usuario tiene el rol con id == 3 (rol amdin)
        if not request.user.rol or request.user.rol.id != 3:
            messages.error(request, "No tienes permisos para realizar esta acción.")
            return redirect('inicio')

        return view_func(request, *args, **kwargs)
    return _wrapped_view

#Vista de página de inicio
def inicio(request):
    return render(request, 'account/inicio.html', {'section': 'inicio'})

#Vista de página de login
def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            User = authenticate(request, 
                                username=cd['username'], 
                                password=cd['password'])
            if User is not None:
                if User.is_active:
                    login(request, User)
                    return HttpResponse('Usuario autenticado')
                else:
                    return HttpResponse('Usuario inactivo')
            else:
                return HttpResponse('Usuario no encontrado')
    else:
        form = LoginForm()
    return render(request, 'account/login.html', {'form': form})

#Vista del registro
def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        if user_form.is_valid():
            new_user = user_form.save(commit=False)
            new_user.set_password(user_form.cleaned_data['password'])
            new_user.save()
            Profile.objects.create(user=new_user)
            return render(request, 'account/register_done.html', {'new_user': new_user})
    else:
        user_form = UserRegistrationForm()
    return render(request, 'account/register.html', {'user_form': user_form})

#Vista del perfil
@login_required
def profile_view(request):
    profile = request.user.profile 
    return render(request, 'account/profile.html', {'profile': profile})

#Vista para editar perfil
@login_required
def edit_profile(request):
    if request.method == 'POST':
        user_form = UserEditForm(request.POST, instance=request.user)
        profile_form = ProfileEditForm(request.POST, request.FILES, instance=request.user.profile)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, "Perfil actualizado correctamente.")
            return redirect('perfil')
        else:
            messages.error(request, "Ocurrió un error al actualizar tu perfil.")
    else:
        user_form = UserEditForm(instance=request.user)
        profile_form = ProfileEditForm(instance=request.user.profile)
    
    return render(request, 'account/edit_profile.html', {
        'user_form': user_form,
        'profile_form': profile_form,
    })

#Vista para crear y mostrar tutorias del tutor registrado
@login_required
@tutor_required
def crear_tutoria(request):
    if request.method == 'POST':
        form = TutoriaForm(request.POST, request.FILES)
        if form.is_valid():
            nueva_tutoria = form.save(commit=False)
            nueva_tutoria.tutor = request.user
            nueva_tutoria.save()
            messages.success(request, "La tutoría se ha creado correctamente.")
            return redirect('crear_tutoria')  
        else:
            messages.error(request, "Error al crear la tutoría. Verifica los datos.")
    else:
        form = TutoriaForm()  

    tutorias = Tutoria.objects.filter(tutor=request.user) 

    return render(request, 'tutorial/create_tutorial.html', {
        'form': form,
        'tutorias': tutorias,  
    })

#Vista para editar tutorias
@login_required
@tutor_required
def editar_tutoria(request, tutoria_id):
    tutoria = get_object_or_404(Tutoria, id=tutoria_id, tutor=request.user)

    if request.method == 'POST':
        form = TutoriaForm(request.POST, request.FILES, instance=tutoria)
        if form.is_valid():
            form.save()
            messages.success(request, "La tutoría se ha actualizado correctamente.")
            return redirect('crear_tutoria')
        else:
            messages.error(request, "Error al actualizar la tutoría. Verifica los datos.")
    else:
        form = TutoriaForm(instance=tutoria)

    return render(request, 'tutorial/edit_tutorial.html', {
        'form': form,
        'tutoria': tutoria,
    })

#Vista para eliminar tutoria
@login_required
@tutor_required
def eliminar_tutoria(request, tutoria_id):
    tutoria = get_object_or_404(Tutoria, id=tutoria_id, tutor=request.user)
    if request.method == 'POST':
        tutoria.delete()
        messages.success(request, "La tutoría se ha eliminado correctamente.")
        return redirect('crear_tutoria')

#Vista para ver las tutorias  
@login_required
def listar_tutorias(request):
    tutorias = Tutoria.objects.all()
    return render(request, 'tutorial/list_tutorials.html',{
        'tutorias':tutorias,
    })


# VISTAS ADMINISTRADOR

# Vista de admin
@login_required
@admin_required
def admin_dashboard(request):
    usuarios = User.objects.all()
    categorias = Categoria.objects.all()
    roles = Rol.objects.all()
    tutorias = Tutoria.objects.all()

    context = {
        'usuarios': usuarios,
        'categorias': categorias,
        'roles': roles,
        'tutorias': tutorias,
    }
    return render(request, 'admin/admin_dashboard.html', context)

# Vist para editar usuarios
@login_required
@admin_required
def editar_usuario_admin(request, user_id):
    usuario = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        form = AdminUserEditForm(request.POST, instance=usuario)
        if form.is_valid():
            form.save()
            messages.success(request, "Usuario actualizado correctamente.")
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Error al actualizar el usuario.")
    else:
        form = AdminUserEditForm(instance=usuario)  # Aquí el formulario correcto
    return render(request, 'admin/edit_user.html', {'form': form, 'usuario': usuario})

# Vista para editar tutoria
@login_required
@admin_required
def editar_tutoria_admin(request, tutoria_id):
    tutoria = get_object_or_404(Tutoria, id=tutoria_id)
    if request.method == 'POST':
        form = AdminTutoriaForm(request.POST, request.FILES, instance=tutoria)
        if form.is_valid():
            form.save()
            messages.success(request, "Tutoría actualizada correctamente.")
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Error al actualizar la tutoría.")
    else:
        form = AdminTutoriaForm(instance=tutoria)
    return render(request, 'admin/edit_tutorial.html', {'form': form, 'tutoria': tutoria})

# Vista para editar categoria
@login_required
@admin_required
def editar_categoria(request, categoria_id):
    categoria = get_object_or_404(Categoria, id=categoria_id)
    if request.method == 'POST':
        form = AdminCategoriaForm(request.POST, instance=categoria)
        if form.is_valid():
            form.save()
            messages.success(request, "Categoría actualizada correctamente.")
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Error al actualizar la categoría.")
    else:
        form = AdminCategoriaForm(instance=categoria)
    return render(request, 'admin/edit_categori.html', {'form': form, 'categoria': categoria})

#Vista para crear categoria
@login_required
@admin_required
def crear_categoria(request):
    if request.method == 'POST':
        form = AdminCategoriaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Categoría creada correctamente.")
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Error al crear la categoría.")
    else:
        form = AdminCategoriaForm()
    return render(request, 'admin/create_categori.html', {'form': form})

#Vista para crear rol
@login_required
@admin_required
def crear_rol(request):
    if request.method == 'POST':
        form = RolForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Rol creado correctamente.")
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Error al crear el rol.")
    else:
        form = RolForm()
    return render(request, 'admin/create_role.html', {'form': form})